<div class="modal"><!-- Place at bottom of page --></div>
</body> 
</html>

<?php

$dbh = null; // Close SQL connection
