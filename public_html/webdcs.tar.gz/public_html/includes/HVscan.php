<?php
/*
 * HVscan.php
 */

exit(1);
// Check if hvscan is ongoing
$hvscan = hvscan_ongoing();

// Check if scan is already running, or if meteo/mainframe connection is ok
$runscan = (!checkMeteo() OR !checkMainFrame()) ? true : false;

// Get HVscan type ID
$type = (filter_input(INPUT_GET, 'type') != NULL) ? filter_input(INPUT_GET, 'type') : '';

// Get all detectors which are not subjected to any test and store in arrays
$sth = $dbh->prepare("SELECT * FROM detectors WHERE mid = :mid AND process = 0");
$sth->execute(array(':mid' => $mid));
$detectors = $sth->fetchAll();

$i=0;
foreach ($detectors as $value) {
    $detectors_id[$i] = $value['id'];
    $detectors_name[$i] = $value['name'];
    $detectors_slot[$i] = $value['slot'];
    $detectors_channel[$i] = $value['channel'];
    $i++;
}

if(filter_input(INPUT_POST, 'startscan') != NULL) {
  
    $start1 = filter_input(INPUT_POST, 'start1');
    $step1 = filter_input(INPUT_POST, 'step1');
    $stop1 = filter_input(INPUT_POST, 'stop1');
    $step2 = filter_input(INPUT_POST, 'step2');
    $stop2 = filter_input(INPUT_POST, 'stop2');
    $step3 = filter_input(INPUT_POST, 'step3');
    $stop3 = filter_input(INPUT_POST, 'stop3');
    $wtime = filter_input(INPUT_POST, 'wtime');
    $mtime = filter_input(INPUT_POST, 'mtime');
    $step = filter_input(INPUT_POST, 'step');
    
    $sel_detectors = $_POST['detectors']; // array of selected detectors
    
    if($start1 == '' OR $step1 == '' OR $stop1 == '' OR $step2 == '' OR $stop2 == '' OR $step3 == '' OR $stop3 == '' OR $wtime == '' OR $mtime == '' OR $step == '') {
        $error = "please fill in all fields.";
    }
    elseif(!is_numeric($start1) OR !is_numeric($step1) OR !is_numeric($stop1) OR !is_numeric($step2) OR !is_numeric($stop2) OR !is_numeric($step3) OR !is_numeric($mtime) OR !is_numeric($wtime) OR !is_numeric($step)) {
        $error = "all fields must be numeric.";
    }
    elseif($av_measuring AND ($mtime-$wtime)%$step != 0) {
        $error = "measure time interval must be a multiple of the total measure time.";
    }
    elseif(count($sel_detectors) == 0) {
        $error = "select a detector.";
    }
    else {
        
        // Get profile name
        if($type != '') {
            
            $q = $dbh->prepare("SELECT type FROM hvscan_config WHERE id = :id");
            $q->execute(array(':id' => $type));
            $f = $q->fetch();
            $profile = $f['type'];
        }
        else {
            $profile = "custom";
        }
        
        // Write HVscan profile to database
        $sth1 = $dbh->prepare("INSERT INTO hvscan (mid, type, start1, step1, stop1, step2, stop2, step3, stop3, measure_time, wait_time, measure_time_interval)
                              VALUES (:mid, :type, :start1, :step1, :stop1, :step2, :stop2, :step3, :stop3, :measure_time, :wait_time, :measure_time_interval) "); 
        $sth1->bindParam(':mid', $mid); 
        $sth1->bindParam(':type', $profile, PDO::PARAM_STR);
        $sth1->bindParam(':start1', $start1); 
        $sth1->bindParam(':step1', $step1); 
        $sth1->bindParam(':stop1', $stop1); 
        $sth1->bindParam(':step2', $step2); 
        $sth1->bindParam(':stop2', $stop2); 
        $sth1->bindParam(':step3', $step3); 
        $sth1->bindParam(':stop3', $stop3); 
        $sth1->bindParam(':measure_time', $mtime); 
        $sth1->bindParam(':wait_time', $wtime); 
        $sth1->bindParam(':measure_time_interval', $step); 
        $sth1->execute();
        
        // Set process = 1 in database
        foreach ($sel_detectors as $value) {

            $t = $dbh->prepare("UPDATE detectors SET process = 1 WHERE id = :id");
            $t->execute(array(':id' => $value));
        }
      
        // Execute script
        // Disable response from script: add " > /dev/null 2>/dev/null &" 
        // Prorgram arguments: hvscan.sh <module ID> <module name>
        $pid = shell_exec($config['exe_dir']."HVscana ".$mid." > /dev/null 2>/dev/null & echo $!");

        // Write pid process to db
        $t = $dbh->prepare("UPDATE modules SET hvscan_pid = :pid WHERE id = :id");
        $t->execute(array(':pid' => $pid, ':id' => $mid));
        header("Location: index.php?q=hvscan");
    }
}
elseif($_POST['stopscan']) {
    
    // Get HVscan pid process for selected mainframe (remember, only one HVscan per mainframe)
    $t = $dbh->prepare("SELECT hvscan_pid FROM modules WHERE id = :mid");
    $t->execute(array(':mid' => $mid));
    $pid = $t->fetch();
    
    exec("/home/user/www/cgi-bin/clearsem.sh"); // Clear semaphore array
    exec("kill ".$pid[0], $out); // Kill process
    $command = $config['exe_dir'].'HVscanStop '.$mid;
    exec($command, $output, $value); // Clean up database and tmp files
    if($output[0] == '0') $pass = 'HVscan stopped.';
    else $error = 'Error while stopping HVscan: '.$output[0].'<br />Please contact the software administrator and report this error.';
}
elseif(filter_input(INPUT_POST, 'setdefault') != NULL) {

    $start1 = filter_input(INPUT_POST, 'start1');
    $step1 = filter_input(INPUT_POST, 'step1');
    $stop1 = filter_input(INPUT_POST, 'stop1');
    $step2 = filter_input(INPUT_POST, 'step2');
    $stop2 = filter_input(INPUT_POST, 'stop2');
    $step3 = filter_input(INPUT_POST, 'step3');
    $stop3 = filter_input(INPUT_POST, 'stop3');
    $wtime = filter_input(INPUT_POST, 'wtime');
    $mtime = filter_input(INPUT_POST, 'mtime');
    $step = filter_input(INPUT_POST, 'step');
    
    if($start1 == '' OR $step1 == '' OR $stop1 == '' OR $step2 == '' OR $stop2 == '' OR $step3 == '' OR $stop3 == '' OR $wtime == '' OR $mtime == '' OR $step == '') {
        $error = "please fill in all fields.";
    }
    elseif(!is_numeric($start1) OR !is_numeric($step1) OR !is_numeric($stop1) OR !is_numeric($step2) OR !is_numeric($stop2) OR !is_numeric($step3) OR !is_numeric($mtime) OR !is_numeric($wtime) OR !is_numeric($step)) {
        $error = "all fields must be numeric.";
    }
    elseif($av_measuring AND ($mtime-$wtime)%$step != 0) {
        $error = "measure time interval must be a multiple of the total measure time.";
    }
    else {
    
        $sql = "UPDATE hvscan_config SET start1 = :start1, step1 = :step1, stop1 = :stop1, step2 = :step2, stop2 = :stop2, step3 = :step3, stop3 = :stop3, mtime = :mtime, wtime = :wtime, step = :step WHERE id = :id";
        $t = $dbh->prepare($sql);
        $t->bindParam(':start1', $start1, PDO::PARAM_INT);  
        $t->bindParam(':step1', $step1);
        $t->bindParam(':stop1', $stop1);
        $t->bindParam(':step2', $step2);
        $t->bindParam(':stop2', $stop2);
        $t->bindParam(':step3', $step3);
        $t->bindParam(':stop3', $stop3);
        $t->bindParam(':mtime', $mtime);
        $t->bindParam(':wtime', $wtime);
        $t->bindParam(':step', $step);
        $t->bindParam(':id', $type);
        $t->execute();
        $pass = 'Configuration successfully saved.';
    }
}
else {
    
    if($type != '') {
        
        $sth = $dbh->prepare("SELECT * FROM hvscan_config WHERE id = :id");
        $sth->execute(array(':id' => $type));
        $cfg = $sth->fetch();

        $start1 = $cfg['start1'];
        $step1 = $cfg['step1'];
        $stop1 = $cfg['stop1'];
        $step2 = $cfg['step2'];
        $stop2 = $cfg['stop2'];
        $step3 = $cfg['step3'];
        $stop3 = $cfg['stop3'];
        $mtime = $cfg['mtime'];
        $wtime = $cfg['wtime'];
        $step = $cfg['step'];
    }
    else {
        
        $start1 = '';
        $step1 = '';
        $stop1 = '';
        $step2 = '';
        $stop2 = '';
        $step3 = '';
        $stop3 = '';
        $mtime = '';
        $wtime = '';
        $step = '';
    }
}

?>

<div class="content">
    
    <div style="display: inline">
        <h3 style="display: inline;">Setup High Voltage scan</h3> &nbsp;&nbsp;&mdash;&nbsp;&nbsp; <?php echo changeModule('hvscan', $mid) ?> 
    </div>
    <br /><br />
  
    <?php 
    if(!empty($error)) { echo '<div class="error">Error: '.$error.'</div>'; }
    elseif($pass != '') { echo '<div class="pass">'.$pass.'</div>'; }

    if(!checkMeteo()) {
        echo '<div class="error">Error: meteo station offline</div>'; 
    }
    if(!checkMainFrame()) {
        echo '<div class="error">Error: mainframe offline</div>'; 
    }
    
    // Select all scan types
    $q = $dbh->prepare("SELECT id, type FROM hvscan_config");
    $q->execute();
    $types = $q->fetchAll();
    ?>
    
    <script type="text/javascript">
    $(document).ready(function() {
        $("#hvscan-form").change(function(){ 
            
            var steps = 1 + (parseInt($('#stop1').val())-parseInt($('#start1').val()))/parseInt($('#step1').val()) + (parseInt($('#stop2').val())-$('#stop1').val())/parseInt($('#step2').val()) + + (parseInt($('#stop3').val())-parseInt($('#stop2').val()))/parseInt($('#step3').val());
            var unittime = parseInt($('#wtime').val()) + parseInt($('#mtime').val());
            var time = unittime*steps/3600;
            $('#esttime').val(time.toFixed(2));
        });
    });
    </script>

    <form method="post" action="" id="hvscan-form">
    <table>
        <tr>
            <td style="height: 40px;">Type scan:</td>
            <td colspan="2">
                <select id="hvscan_type" name="typescan">
                    <option value="" <?php if($type == '') { echo 'selected="selected"'; } ?>>Custom profile</option>
                    <?php 
                    
                    foreach($types as $value) {
                        
                        $sel = ($type == $value['id']) ? 'selected="selected"' : '';
                        echo '<option '.$sel.' value="'.$value['id'].'">'.$value['type'].'</option>';
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td width="100px">HV Start 1 [V]:</td>
            <td width="200px"><input size="12" id="start1" name="start1" type="text" value="<?php echo $start1 ?>" /></td>
            <td style="vertical-align: top;" width="200px;" rowspan="12">
                <select multiple="multiple" name="detectors[]" style="width: 175px; height: 275px;">
                    <option disabled="disabled">Available detectors:</option>
                    <?php
                    foreach ($detectors as $value) {
                        echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>HV step 1 [V]:</td>
            <td><input size="12" id="step1" name="step1" type="text" value="<?php echo $step1 ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td>HV stop 1 [V]:</td>
            <td><input size="12" id="stop1" name="stop1" type="text" value="<?php echo $stop1 ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td>HV step 2 [V]:</td>
            <td><input size="12" id="step2" name="step2" type="text" value="<?php echo $step2 ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td>HV stop 2 [V]:</td>
            <td><input size="12" id="stop2" name="stop2" type="text" value="<?php echo $stop2 ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td>HV step 3 [V]:</td>
            <td><input size="12" id="step3" name="step3" type="text" value="<?php echo $step3 ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td>HV stop 3 [V]:</td>
            <td><input size="12" id="stop3" name="stop3" type="text"  value="<?php echo $stop3?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td width="100px">Wait time* [s]:</td>
            <td><input size="12" id="wtime" name="wtime" type="text" value="<?php echo $wtime ?>" /></td>
            <td></td>       
        </tr>
        <tr>
            <td width="150px">Measure time [s]:</td>
            <td><input size="12" name="mtime" type="text" id="mtime" value="<?php echo $mtime ?>" /></td>
            <td></td>
        </tr>
        <tr>
            <td width="100px">Measure time interval [s]:</td>
            <td><input size="12" name="step" type="text" id="step" value="<?php echo $step ?>" /></td>
            <td></td> 
        </tr>  
        <tr>
            <td width="100px">Estimated time [h]:</td>
            <td><input disabled="disabled" size="12" name="step" type="text" id="esttime" value="<?php echo $time ?>" /></td>
            <td></td> 
        </tr>
    </table>
    <br />
    <?php
    if($hvscan) {
        $input = '<input onclick="return confirm("Do you really want to stop the HVscan?");" type="submit" name="stopscan" value="Stop HVscan" />';
        $title = "HVscan logfile: current scan";
    }
    else {
        if($runscan) {
            $input = '<input disabled="disabled" type="submit" id="startscan" name="startscan" value="Start HV scan" />';
        }
        else {
            $input = '<input type="submit" id="startscan" name="startscan" value="Start HV scan" />';
        }
        $title = "HVscan logfile: previous scan";
    }
    ?>
    <?php echo $input ?> <input <?php if($type == "") { echo 'disabled="disabled"'; } ?> type="submit" name="setdefault" value="Set as default values" /> &nbsp;&nbsp; *<font style="font-size: 10px;">This is the measure time after ramping up is completed.</font>
  
    </form>   
    
    <br /><br />

    <div style="display: inline">
        <h3 style="display: inline;"><?php echo $title; ?></h3>
    </div>
    <br /><br />
    <script type="text/javascript"> $(document).ready(function() { readLogFile(); }); </script> 
    <div class="logfile" id="logFile">Log file</div>

</div>
