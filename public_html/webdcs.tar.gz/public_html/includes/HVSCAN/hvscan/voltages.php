<?php

// Get all chambers in current scan
$sth1 = $dbh->prepare("SELECT trolley, slot, chamber FROM detectors d, hvscan_VOLTAGES h WHERE h.scanid = $id AND h.detectorid = d.id GROUP BY d.chamber ORDER by d.trolley, d.slot ASC");
$sth1->execute();
$chambers = $sth1->fetchAll();


$resume = true;

if(isset($_POST['resume'])) { // STATUS = 4 = RESUME
    
    // Loop over all points
    for($i=1; $i <= $hvscan['maxHVPoints']; $i++) {
        

        if(isset($_POST['HV'.$i])) {
        
            // Unmask the selected points
            $sth1 = $dbh->prepare("UPDATE hvscan_VOLTAGES SET masked = 0 WHERE HVPoint = $i AND scanid = ".$id);
            $sth1->execute();
            
            // Delete corresponding files
            shell_exec("rm /var/operation/HVSCAN/".$idstring."/*_HV".$i."_CAEN.root");
            shell_exec("rm /var/operation/HVSCAN/".$idstring."/*_HV".$i."_DIP.root");
            shell_exec("rm /var/operation/HVSCAN/".$idstring."/*_HV".$i."_DAQ.root");
            shell_exec("rm /var/operation/HVSCAN/".$idstring."/*_HV".$i."_DAQ-Rate.root");
            shell_exec("rm -rf /var/operation/HVSCAN/".$idstring."/HV".$i);     
        }
        
        else {
            
            // Mask the non-selected points
            $sth1 = $dbh->prepare("UPDATE hvscan_VOLTAGES SET masked = 1 WHERE HVPoint = $i AND scanid = ".$id);
            $sth1->execute();
        }
    }
    
    // Update status
    $sth1 = $dbh->prepare("UPDATE hvscan SET status = 4 WHERE id = ".$id);
    $sth1->execute();
    
    // Start scan  
	startCAEN("HVscan", $id);
    //$pid = shell_exec("/home/webdcs/software/CAEN/webdcs/HVscan.sh ".$id);
    
    // Write pid process to db
    //$t = $dbh->prepare("UPDATE modules SET hvscan_pid = :pid WHERE id = 1");
    //$t->execute(array(':pid' => $pid));
    
    // Append line to log file
    $log = sprintf("%s.[WEBDCS] HVscan resumed by user (PID=%d)\n", date('Y-m-d.H.i.s'), $pid);
    $logfile = sprintf("/var/operation/HVSCAN/%06d/log.txt", $id);
    file_put_contents($logfile, $log, FILE_APPEND);

    header("Location: index.php?q=hvscan&p=ongoing");
    //header("Location: index.php?q=hvscan&type=current");
}


?>

<form action="" method="POST">
<table class="table">

	<thead>
            
		<?php
        $remaining = ($TYPESCAN == "daq") ? 1000 - 100 - count($chambers)*60 - 220 - 30 : 900 - 100 - count($chambers)*60 -220 - 30;
        
		echo '<tr>';
        echo '<td class="oddrow" width="70px">HV<sub>eff</sub></td>';
		echo '<td class="oddrow" width="20px">DQM</td>';
		
		if($TYPESCAN == "daq") echo '<td width="50px" class="oddrow">Triggers</td>';
		foreach($chambers as $chamber) {

			echo '<td class="oddrow" width="60px"><div class="tooltip">T'.$chamber['trolley'].'_S'.$chamber['slot'].'<span class="tooltiptext">'.$chamber['chamber'].'</span></div></td>';
        }
	
        echo '<td class="oddrow" width="'.$remaining.'"></td>';
		echo '</tr></thead>';

		echo '<tbody>';
        for($i = 0; $i < $hvscan['maxHVPoints']; $i++) {
            
            $class = ($i%2 == 0) ? 'odd' : 'even';
            echo '<tr class="'.$class.'">';
                          //  if($resume) echo '<td>'.($i+1).' <input style="height: 10px;" type="checkbox" name="HV'.($i+1).'" /></td>';

            if($hvscan['RPC_mode'] == 'double_gap') {
                if($resume) echo '<td>'.($i+1).' <input style="height: 10px;" type="checkbox" name="HV'.($i+1).'" /></td>';
                else echo '<td>'.($i+1).'</td>';
            }
            else echo '<td>BOT '.($i+1).'<br />TOP/TN '.($i+1).'<br />TW '.($i+1).'</td>';
            
			echo '<td style="border-right: 1px solid #EEE; border-left: 1px solid #EEE;"><a href="index.php?q=hvscan&p=hvscan&id='.$id.'&r=dqm_caen&HV='.($i+1).'">DQM</a></td>';
            
			if($TYPESCAN == "daq") {
                echo '<td style="border-right: 1px solid #EEE;">'.getMaxTriggers($chamber['trolley'], $chamber['slot'], $i+1, $id).'</td>';
            }
			
			
            $j = 0;
            foreach($chambers as $chamber) {
            
                if($hvscan['RPC_mode'] == 'double_gap') {
                    echo '<td class="'.$class.'">'.getHV($chamber['trolley'], $chamber['slot'], $i+1, $id).'</td>';
                }
                else {
                    
                    // Check the amount of gaps for this slot
                    $a = $dbh->prepare("SELECT * FROM detectors WHERE trolley = ".$chamber['trolley']." AND slot = ".$chamber['slot']." ORDER BY name ASC ");
                    $a->execute();
                    $gaps = $a->fetchAll();
                    $noGaps = $a->rowCount();

                    
                    
                    echo '<td valign="top" class="'.$class.'">';
                    foreach($gaps as $gap) {
                        echo getHV($chamber['trolley'], $chamber['slot'], $i+1, $id, $gap['id']).'<br />';
                    }
                    echo '</td>';
                }
                $j++;
            }
     
            
            echo '<td width="'.$remaining.'"></td>';
            
            echo '</tr>';
        }
        
        $class = ($hvscan['maxHVPoints']%2 == 0) ? 'evenrow' : 'oddrow';
        
        
        ?>
    </tbody>
</table>
	
<?php
if($resume) {
	

	echo '<br /><input type="submit" name="resume" value="Resume" />';
}

?>
	
</form>
    
