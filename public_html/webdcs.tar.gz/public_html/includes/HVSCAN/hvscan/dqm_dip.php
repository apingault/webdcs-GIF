<?php

echo '<div class="dqm-images">';

echo '<h3>Environmental parameters</h3>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/P201.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/P201.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/T201.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/T201.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/RH201.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/RH201.png" /></a>';
    
echo '<h3>Source parameters</h3>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/SourceON.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/SourceON.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/AttUEff.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/AttUEff.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/AttDEff.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/AttDEff.png" /></a>';
    
    
echo '<h3>Gas parameters</h3>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/C2H2F4.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/C2H2F4.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/iC4H10.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/iC4H10.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/SF6.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/SF6.png" /></a>';
   
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/RPC_MFC_Humidity.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/RPC_MFC_Humidity.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/mixture_with_water.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/mixture_with_water.png" /></a>';
echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/mixture_without_water.png"><img width="33%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DIP/mixture_without_water.png" /></a>';
    

echo '</div>';

?>


<script>
$(document).ready(function() {
	$('.dqm-images').magnificPopup({
	  delegate: 'a',
	  type: 'image',
	  gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0,1] // Will preload 0 - before current, and 1 after the current image
			  },
	});
});
</script>