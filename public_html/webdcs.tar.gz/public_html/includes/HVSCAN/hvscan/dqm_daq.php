<?php

echo '<div class="dqm-images">';
foreach($trollies as $trolley) {
    
    if(str_replace(" ", "", $trolley) == "") continue;

	$sth1 = $dbh->prepare("SELECT d.slot, d.name, d.chamber FROM detectors d, hvscan_VOLTAGES v WHERE v.HVPoint = $HV AND v.scanid = $id AND v.detectorid = d.id AND d.trolley = $trolley GROUP BY d.slot");
	$sth1->execute();
	$gaps = $sth1->fetchAll();

	foreach($gaps as $gap) {

		$T = $trolley;
		$S = $gap['slot'];
		$t = array('A', 'B', 'C', 'D');
		echo '<h3>Trolley '.$trolley.' - Slot '.$gap['slot'].' ('.$gap['chamber'].')</h3>';
		
		foreach($t as $PARTITION) {

			if(file_exists('/var/operation/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Hit_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png')) {
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Hit_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Hit_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>';
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Beam_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Beam_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>';
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Hit_Multiplicity_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Hit_Multiplicity_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>';
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Mean_Noise_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Mean_Noise_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>';
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Instant_Noise_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Instant_Noise_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>'; 
				echo '<a href="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Time_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png"><img width="16.6%" src="/HVSCAN/'.$idstring.'/HV'.$HV.'/DAQ/RPC_Time_Profile_T'.$T.'S'.$S.'_'.$PARTITION.'.png" /></a>'; 
			}  
		}
	}
}

echo '</div>';
?>


<script>
$(document).ready(function() {
	$('.dqm-images').magnificPopup({
	  delegate: 'a',
	  type: 'image',
	  gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0,1] // Will preload 0 - before current, and 1 after the current image
			  },
	});
});
</script>