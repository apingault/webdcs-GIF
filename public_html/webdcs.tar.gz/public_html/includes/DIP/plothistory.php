<?php

require_once 'functions.php';

loadCSS("datetimepicker.css");
loadJS("datetimepicker.js");

// Get parameters, grouped by table_name
$sth1 = $dbhDIP->prepare("SELECT * FROM parameters GROUP BY table_name");
$sth1->execute();
$cats = $sth1->fetchAll();

$params = array();
foreach($cats as $cat) {

	$sth1 = $dbhDIP->prepare("SELECT * FROM parameters WHERE table_name = '".$cat['table_name']."'");
	$sth1->execute();
	$pars = $sth1->fetchAll();
	
	$params['NONE-'.$cat['table_name']] = $cat['category'];
	foreach($pars as $param) $params[$param["id_name"]] = $param["name"];
	//array_push($params, "");
}
array_pop($params); // remove last empty key


if(isset($_POST['submit'])) {
    
    $t1 = strtotime($_POST['time1']);
    $t2 = strtotime($_POST['time2']);
    $id_name1 = $_POST['param1'];
    $id_name2 = $_POST['param2'];
}
else {

    $t1 = time() - 24*3600;
    $t2 = time();
    $id_name1 = "P";
    $id_name2 = "TIN";
}


$datapoints1 = getDataPointsFromDB($id_name1, $t1, $t2);
$datapoints2 = getDataPointsFromDB($id_name2, $t1, $t2);

getDIPParamInfo($id_name1, $paramName1, $paramUnit1, $DBtable1);
getDIPParamInfo($id_name2, $paramName2, $paramUnit2, $DBtable2);

//print_r($datapoints1);

?>


<script src="http://canvasjs.com/assets/script/canvasjs.min.js"></script>

<h3>Plot monitoring history</h3>
    
<form action="" method="post">
        
	<table>
		<tr>
			<td style="width: 120px;">Start time:</td>
            <td><input id="time1" name="time1" type="text" value="<?php echo date("Y/m/d H:i", $t1); ?>" /></td>
        </tr>
        
		<tr>
            <td>End time:</td>
            <td><input id="time2" name="time2" type="text" value="<?php echo date("Y/m/d H:i", $t2); ?>" /></td>
        </tr>
		
        <tr>
            <td>Parameter left:</td>
            <td>
				<select name="param1">
				<?php
				$prevCat = "";
				foreach($params as $i => $p) {
					if(strpos($i, "NONE") !== false) {
						echo '<option disabled="disabled">'.$p.'</option>';
					}
					else {
						//echo $i.' '.$id_name1.'<br>';
						$sel = ($id_name1 == $i) ? 'selected="selected"' : '';
						echo '<option '.$sel.' value="'.$i.'">'.$p.'</option>';
					}
				}
				?> 
				</select> (red)
			</td>
		</tr>
		
        <tr>
            <td>Parameter right:</td>
            <td>
				<select name="param2">
					<?php
					foreach($params as $i => $p) {

						if(strpos($i, "NONE") !== false) {
						echo '<option disabled="disabled">'.$p.'</option>';
						}
						else {
							//echo $i.' '.$id_name1.'<br>';
							$sel = ($id_name2 == $i) ? 'selected="selected"' : '';
							echo '<option '.$sel.' value="'.$i.'">'.$p.'</option>';
						}
					}
					?> 
				</select> (blue)
			</td>
		</tr>
            
        <tr>
			<td style="height: 30px;"></td>
			<td><input type="submit" name="submit" value="Generate plot"></td>
		</tr>
            
	</table>

</form>
    

 
  
<script type="text/javascript">
    window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer", 
    {
      title:{
      text: "<?php echo $paramName; ?>"
      },
      axisX:{
        title: "Date",
        interval:10, 
        gridThickness: 1,
        titleFontSize: 16,
        labelFontSize: 12,
      },
      axisY:{
        title: "<?php echo $paramName1.' ['.$paramUnit1.']'?>",
        titleFontSize: 16,
        gridThickness: 1,
        labelFontSize: 12,
		titleFontColor: "red",
      },
      axisY2:{ 
        title: "<?php echo $paramName2.' ['.$paramUnit2.']'?>",
        titleFontSize: 16,
        gridThickness: 1,
        labelFontSize: 12,
		titleFontColor: "blue",
      },
      zoomEnabled: true, 
      zoomType: "xy",
      data: [{        
        type: "line",
        xValueType: "dateTime",
		color: "red",
        dataPoints: [<?php echo $datapoints1; ?>]
      },
      {        
        type: "line",
        xValueType: "dateTime",
        axisYType: "secondary",
		color: "blue",
        dataPoints: [<?php echo $datapoints2; ?>]
      }
      ]
    });

    chart.render();
  }
</script>

<script src="http://canvasjs.com/assets/script/canvasjs.min.js"></script>
<div id="chartContainer" style="height: 350px; width: 95%; float: left; margin-top: 15px;">
</div>   




    <script type="text/javascript">// <![CDATA[
    jQuery(function(){jQuery('#time1').datetimepicker();});
    jQuery(function(){jQuery('#time2').datetimepicker();});
    // ]]></script>
    
