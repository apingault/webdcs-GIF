<?php
require_once 'functions.php';

?>

<h3 style="display: inline;">DIP manager</h3>
    
<br /><br />
&raquo; <a href="index.php?q=dip&p=plothistory">Plot monitoring history</a><br />
&raquo; <a href="index.php?q=dip&p=subscriptions">DIP Subscriptions</a><br />


<script type="text/javascript">
	$(document).ready(function() { DIPMonitor(); });
</script>
<div id="DIPMonitor"></div>