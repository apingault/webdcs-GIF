<?php



function getDIPParamInfo($id_name, &$paramName, &$paramUnit, &$DBtable) {
	
	global $dbhDIP;
	
	$sth1 = $dbhDIP->prepare("SELECT * FROM parameters WHERE id_name = '$id_name'");
    $sth1->execute();
	$res = $sth1->fetch();
	
	$paramName = $res["name"];
	$paramUnit = $res["unit"];
	$DBtable = $res["table_name"];
}


function getDataPointsFromDB($paramID, $t1, $t2) {
	
	global $dbhDIP;
    
    $datapoints = "";
    $paramName = "";
    $paramUnit = "";
    $DBtable = "";
	
    getDIPParamInfo($paramID, $paramName, $paramUnit, $DBtable);
	
    $sql = sprintf("SELECT timestamp, %s FROM %s WHERE timestamp > %d AND timestamp < %d", $paramID, $DBtable, $t1, $t2);
    $sth1 = $dbhDIP->prepare($sql);
	//echo $sql;
    $sth1->execute();
    $values = $sth1->fetchAll();
    foreach($values as $val) {

        $time = $val[0]*1000;
        if($DBtable) $datapoints .= "{ x: ".$time.", y: ".$val[1]." }, ";
    }
    
    return $datapoints;
}

function getDataPointsFromDBAverage($paramID, $t1, $t2) {
	
	global $dbhDIP;
    
    $datapoints = "";
    $paramName = "";
    $paramUnit = "";
    $DBtable = "";
	
    getDIPParamInfo($paramID, $paramName, $paramUnit, $DBtable);
	
    $sql = sprintf("SELECT timestamp, %s FROM %s WHERE timestamp > %d AND timestamp < %d", $paramID, $DBtable, $t1, $t2);
    $sth1 = $dbhDIP->prepare($sql);
	//echo $sql;
    $sth1->execute();
    $values = $sth1->fetchAll();
	$ret = 0.0;
	$points = 0;
    foreach($values as $val) {

		$ret += $val[1];
		$points++;
    }
    
    return $ret / $points;;
}

function getDIPParams() {
	
	global $dbhDIP;
	
	// Get parameters, grouped by table_name
	$sth1 = $dbhDIP->prepare("SELECT * FROM subscriptions GROUP BY table_name");
	$sth1->execute();
	$cats = $sth1->fetchAll();
	$params = array();
	$params['-'] = "None";
	foreach($cats as $cat) {

		$sth1 = $dbhDIP->prepare("SELECT * FROM subscriptions WHERE table_name = '".$cat['table_name']."'");
		$sth1->execute();
		$pars = $sth1->fetchAll();

		$params['NONE-'.$cat['table_name']] = $cat['category'];
		foreach($pars as $param) $params[$param["id_name"]] = $param["name"];
		//array_push($params, "");
	}
	array_pop($params); // remove last empty key
	
	return $params;
}