<?php
if(!defined('INDEX')) die("Access denied");
require_once(ROOT.'/config/config.php');
require_once(ROOT.'/config/functions.php');

$menu = array(
	"Monitoring" => array("DIP" => "index.php?q=dip", "PMON" => "index.php?q=pmon", "Log file" => "index.php?q=pmon&p=logfile",),
	"HVscan" => array("DAQ Run Registry" => "index.php?q=hvscan&p=runregistry&type=daq", "Current Run Registry" => "index.php?q=hvscan&p=runregistry&type=current",),
	"Longevity" => array("Run registry" => "index.php?q=longevity&p=runregistry", "Summary" => "index.php?q=longevity&p=summary"),
	"Hardware" => array("Gas flows" => "index.php?q=gasflow", "Trolley position" => "index.php?q=position", "Detectors" => "index.php?q=detectors"),
	"Settings" => array("DCS Settings" => "index.php?q=dcssettings", "DAQ Ini config" => "index.php?q=dcssettings&p=daqini"),
	"Account" => array("Settings" => "index.php?q=account", "Log out" => "index.php?q=logout"),
);



if(HVscanOngoing() == -1) {
	
	$menu["HVscan"]["Start DAQ HVscan"] = "index.php?q=hvscan&p=startscan&type=daq";
	$menu["HVscan"]["Start Current HVscan"] = "index.php?q=hvscan&p=startscan&type=current";
}
else $menu["HVscan"]["Ongoing run"] = "index.php?q=hvscan&p=ongoing";


if(stabilityOngoing() == -1) $menu["Longevity"]["Start run"] = "index.php?q=longevity&p=startrun";
else $menu["Longevity"]["Ongoing run"] = "index.php?q=longevity&p=ongoing";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<title><?php echo settings('title'); ?></title>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	<?php 
	loadCSS("screen.css");
	loadCSS("magnific-popup.css");
	//loadJS("jquery-1.10.2.min.js");
	
	loadJS("jquery.tablesorter.min.js");
	loadJS("jquery.tablesorter.widgets.js");
	loadCSS("tablesorter.css");
	
	loadJS("ajax.js");
	loadJS("js.js");
	loadJS("multiselect.js");
	loadJS("jquery.magnific-popup.min.js"); 
	?>

	<link rel="stylesheet" type="text/css" href="config/css/" />
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	
</head>

<body>

    <div class="header">    
        
		<div class="headertext">
			WebDCS <?php echo EXPERIMENT_NAME ?>
			<div class="logo"><img alt="" src="config/images/cms.gif" width="75px" /></div>
		</div>
	</div>
	
	<div class="navigation">
        
		<div class="nav">
		<ul>
		<?php
		foreach($menu as $key => $val) {
		
			if(is_array($val)) {
				echo '<li><a href="#">'.$key.'</a><ul>';
				foreach($val as $key1 => $val1) {
					echo '<li><a href="'.$val1.'">'.$key1.'</a></li>';
				}
				echo '</ul></li>';
			}
			else echo '<li><a href="'.$val.'">'.$key.'</a></li>';
				
		}
		?>
        
      </ul>
		
        </div>
    </div>
