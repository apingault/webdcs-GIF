<?php

showLogFile($dir."/log.txt", true);
