<?php

require_once '../PMON/php/functions.php';
require_once '../DIP/php/functions.php';

echo '<div class="content">';
    
if(isset($_GET['p'])) require 'PMON/'.$_GET['p'].'.php';
else require 'PMON/index.php';

echo '</div>';
echo '<br /><br />';

