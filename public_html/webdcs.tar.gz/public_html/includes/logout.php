<?php
if(!defined('INDEX')) die("Access denied");

require_once 'library/login/logout.php';