<?php

// Select all chambers
$sth1 = $dbh->prepare("SELECT * FROM chambers ORDER by trolley, slot ASC");
$sth1->execute();
$chambers = $sth1->fetchAll();

?>


<div style="display: inline">
	<h3 style="display: inline;">Configure detectors</h3>
</div>

<br /><br />

<table class="table">
    
	<thead>
	<tr>
		<td width="50px">Action</td>
        <td width="160x">Detector name</td>
        <td width="70px">Position</td>
        <td width="60px">Gaps</td>
        <td width="40px">Partitions</td>
        <td width="40px">Strips</td>
		<td width="40px">DAQ type</td>
		<td width="80px">HV WP</td>
		<td width="80px">HV STBY</td>
    </tr>
    </thead>
	
    <tbody>
    <?php
    $i = 0;
    foreach ($chambers as $value) {
        
        $trolley = $value['trolley'];
        $slot = $value['slot'];
		
		if($trolley == 0) $pos = "S".$slot;
		else $pos = "T".$trolley.'S'.$slot;
		
		$img = ($value['enabled'] == 1) ? $ICON_TICK : $ICON_CROSS;
		
		
		echo '<td>'.$img.'&nbsp;&nbsp; <a href="index.php?q=detectors&p=editchamber&id='.$value['id'].'">'.$ICON_EDIT.'</a></td>';
		
		echo '<td>'.$value['name'].'</td>';
		echo '<td>'.$pos.'</td>';
		echo '<td>'.$value['gaps'].'</td>';
		echo '<td>'.$value['partitions'].'</td>';
		echo '<td>'.$value['strips'].'</td>';
		echo '<td>'.$value['daq_type'].'</td>';
		echo '<td>'.$value['HV_WP'].'</td>';
		echo '<td>'.$value['HV_STBY'].'</td>';
		
		echo '</tr>';
		/*
        foreach($detectors as $det) {
            
			if($det['trolley'] != $trolley or $det['slot'] != $slot) continue;
			
            

            echo '<tr>';
			echo '<td>'.$img.'</td>';
            echo '<td>T'.$trolley.'_S'.$slot.'</td>';
            echo '<td>'.$det['name'].'</td>';
            echo '<td>'.$det['CAEN_slot'].'</td>';
            echo '<td>'.$det['CAEN_channel'].'</td>';
            echo '<td>'.$det['ADC_slot'].'</td>';
            echo '<td>'.$det['ADC_channel'].'</td>';
            echo '<td>';
            echo ($det['DAQ'] == 0) ? $ICON_TICK : $ICON_CROSS;;
            echo '</td>';
            echo '<td>';
            echo ($det['RCURR'] == 0) ? $ICON_TICK : $ICON_CROSS;;
            echo '</td>';
			echo '<td>';
            echo ($det['stability'] == 0) ? $ICON_TICK : $ICON_CROSS;
            echo '</td>';
            echo '<td>';
            echo ($det['RCURR'] == 0) ? '-' : $det['ADC_resistor'];
            echo '</td>';
			echo '<td>'.$det['hv_wp'].'</td>';
			echo '<td>'.$det['hv_standby'].'</td>';
            echo '</tr>';
			
        }*/
        $i++;
    }
    ?>
    </tbody>
</table>