<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<h3 style="display: inline;">DIP monitoring status</h3>
    