<?php

// Get information of a processes by invoking the ps -Al command to extract info/PID
function getProccessInfo($proc, &$running, &$PID = "", &$PS = "") {

	$running = false;
	
	$process = shell_exec("ps -Al | grep ".$proc);
	if($process != "") {
		
		$running = true;
		$PS = nl2br($process);
	}
	else $PS = "n/a";

	$PID = shell_exec("ps -Al | grep ".$proc." | awk '{print $4}'");
	if($PID == "") $PID = "n/a";
	else $PID = nl2br($PID);
}
