<?php

/** Configuration Variables **/


/** DEV TRUE OR FALSE **/
define ('DEVELOPMENT_ENVIRONMENT',true);


/** DATABASE SETTINGS **/
define('DB_NAME', 'webdcs');
define('DB_USER', 'root');
define('DB_PASSWORD', 'UserlabGIF++');
define('DB_HOST', 'localhost');

/** SITE SETTINGS **/
define('SITE_NAME', 'WebDCS GIF++');
define('DOMAIN_NAME', 'webdcs.cern.ch');
define('REL_PATH', '/'); // relative path to document root (WITH SLASH AT BEGIN AND END)


/** ADVANCED SETTINGS **/
$upload_limit = 1024 * 1024 * 20; // in bytes


// Define some directory constants
define('DS', DIRECTORY_SEPARATOR);
define('ROOT', $_SERVER['DOCUMENT_ROOT'] . REL_PATH );
define('DOMAIN_ROOT', 'http://' . $_SERVER['SERVER_NAME'] . REL_PATH );
session_cache_expire(20); // 20 min


session_start();
ob_start();



// Define the experiment
// Interface can change from experiment to experiment
define('EXPERIMENT', 'GIFPP'); // GIFPP or 904 or other experiment
define('EXPERIMENT_NAME', 'GIF++'); // experiment name as appear in the interface