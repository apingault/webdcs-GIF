<?php

global $controllogin;
$controllogin->Logout();
header("Location: index.php");	
