<?php 
if(!defined('INDEX')) die("Access denied");

$dbh = null;
$dbh1 = null;
$dbhDIP = null;
$dbhLONG = null;

// Load main functions
require_once (ROOT.'/library/functions.php');

// Make database connection(s)
db_connect();
db_connect1();


// Check login or go to login page
require_once url('library/login/controllogin.class.php', 'local');
$controllogin = new ControlLogin();
if($controllogin->CheckSession()) loadCore(); // load default website
else require_once 'library/login/login.php';



