<?php
$id = $_GET['id'];
$idstring = sprintf("%06d", $id);
$filename = "/var/operation/HVSCAN/".$idstring."/log.txt";
if(file_exists($filename)) {
    $file = glob($filename); // search for .log file
    echo '<pre>';
    $log = array_reverse(file($file[0]));
    foreach ($log as $line) {
        echo trim($line) . '<br />';
    }
    echo '</pre>';
}
else echo "<pre>No log file found</pre>";


